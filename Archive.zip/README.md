# WDI-PROJECT-1
This is my first project from my WDI course at General Assembly
